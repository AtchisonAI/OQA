﻿using System;

namespace Tibco.ServiceModel
{
    internal delegate TResult CommunicationOperation<TResult, TArg>(TimeSpan timeout, out TArg arg0);
}