﻿using System;
using System.ServiceModel.Configuration;

namespace Tibco.ServiceModel
{
    public sealed class TibcoBindingSection : StandardBindingCollectionElement<TibcoBinding, TibcoBindingConfigurationElement>
    {
        public TibcoBindingSection()
        {
        }
    }
}