﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using TIBCO.Rendezvous;

namespace Tibco.ServiceModel
{
    internal sealed class TibcoChannelFactory : ChannelFactoryBase<IOutputChannel>
    {
        private readonly BindingContext _context;

        private readonly Action<TimeSpan> _openMethod;

        private readonly TibcoTransportBindingElement _bindingElement;

        private NetTransport _transport;
        private CMTransport _model;

        public TibcoChannelFactory(BindingContext context)
        {
            this._context = context;
            this._openMethod = new Action<TimeSpan>(this.Open);
            this._bindingElement = context.Binding.Elements.Find<TibcoTransportBindingElement>();
            this._model = null;
        }

        protected override void OnAbort()
        {
            base.OnAbort();
            this.OnClose(this._context.Binding.CloseTimeout);
        }

        protected override IAsyncResult OnBeginOpen(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this._openMethod.BeginInvoke(timeout, callback, state);
        }

        protected override void OnClose(TimeSpan timeout)
        {
            if (this._model != null)
            {
                //this._bindingElement.Close(this._model, timeout);
                this._model.Destroy();
                this._model = null;
            }

            if (this._transport != null)
            {
                this._transport.Destroy();
                this._transport = null;
            }
        }

        protected override IOutputChannel OnCreateChannel(EndpointAddress address, Uri via)
        {
            return new TibcoOutputChannel(this._context, this._model, address);
        }

        protected override void OnEndOpen(IAsyncResult result)
        {
            this._openMethod.EndInvoke(result);
        }

        protected override void OnOpen(TimeSpan timeout)
        {
            TIBCO.Rendezvous.Environment.Open();

            this._transport = new NetTransport(_bindingElement.Service, _bindingElement.Network, _bindingElement.Deamon);
            this._model = new CMTransport(_transport);
            //this._model = this._bindingElement.Open(timeout);
        }
    }
}