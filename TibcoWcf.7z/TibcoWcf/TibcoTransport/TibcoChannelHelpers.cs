﻿//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

using System;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Tibco.ServiceModel
{
    /// <summary>
    /// Collection of constants used by the Udp Channel classes
    /// </summary>
    static class TibcoConstants
    {
        internal const string Scheme = "soap.tibco";

        static MessageEncoderFactory messageEncoderFactory;
        static TibcoConstants()
        {
            messageEncoderFactory = new TextMessageEncodingBindingElement().CreateMessageEncoderFactory();
        }

        // ensure our advertised MessageVersion matches the version we're
        // using to serialize/deserialize data to/from the wire
        internal static MessageVersion MessageVersion
        {
            get
            {
                return messageEncoderFactory.MessageVersion;
            }
        }

        // we can use the same encoder for all our Udp Channels as it's free-threaded
        internal static MessageEncoderFactory DefaultMessageEncoderFactory
       {
            get
            {
                return messageEncoderFactory;
            }
        }
    }

    static class TibcoConfigurationStrings
    {
        //public const string MaxBufferPoolSize = "maxBufferPoolSize";
        //public const string MaxReceivedMessageSize = "maxMessageSize";
        //public const string Multicast = "multicast";
        //public const string OrderedSession = "orderedSession";
        //public const string ReliableSessionEnabled = "reliableSessionEnabled";
        //public const string SessionInactivityTimeout = "sessionInactivityTimeout";
        //public const string ClientBaseAddress = "clientBaseAddress";
        public const string Service = "service";
        public const string Network = "network";
        public const string Deamon = "deamon";
        public const string DQName = "dqName";
        public const string UseCMDQ = "useCMDQ";
    }

    static class TibcoPolicyStrings
    {
        public const string TibcoNamespace = "http://sample.schemas.microsoft.com/policy/tibco";
        public const string Prefix = "tibco";
        public const string MulticastAssertion = "Multicast";
        public const string TransportAssertion = "soap.tibco";
    }

    static class TibcoChannelHelpers
    {
        /// <summary>
        /// The Channel layer normalizes exceptions thrown by the underlying networking implementations
        /// into subclasses of CommunicationException, so that Channels can be used polymorphically from
        /// an exception handling perspective.
        /// </summary>
        internal static CommunicationException ConvertTransferException(TIBCO.Rendezvous.RendezvousException rvException)
        {
            return new CommunicationException(
                string.Format(CultureInfo.CurrentCulture, 
                "A Tibco error ({0}: {1}) occurred while transmitting data.", rvException.StatusText, rvException.Message),
                rvException);
        }

        internal static void ValidateTimeout(TimeSpan timeout)
        {
            if (timeout < TimeSpan.Zero)
            {
                throw new ArgumentOutOfRangeException("timeout", timeout, "Timeout must be greater than or equal to TimeSpan.Zero. To disable timeout, specify TimeSpan.MaxValue.");
            }
        }
    }

    static class TibcoDefaults
    {
        internal const string service = "";
        internal const string network = "7500";
        internal const string deamon = "localhost";
        internal const string dqName = "HiDM.CIM";

        internal const long MaxBufferPoolSize = 64 * 1024;
        internal const int MaxReceivedMessageSize = 5 * 1024 * 1024; //64 * 1024;
        //internal const bool Multicast = false;
        //internal const bool OrderedSession = true;
        //internal const bool ReliableSessionEnabled = true;
        //internal const string SessionInactivityTimeoutString = "00:10:00";
    }

    static class AddressingVersionConstants
    {
        internal const string WSAddressing10NameSpace = "http://www.w3.org/2005/08/addressing";
        internal const string WSAddressingAugust2004NameSpace = "http://schemas.xmlsoap.org/ws/2004/08/addressing";
    }
}
