﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using TIBCO.Rendezvous;

namespace Tibco.ServiceModel
{
    internal sealed class TibcoChannelListener<TChannel> : TibcoChannelListenerBase<IInputChannel>
    where TChannel : class, IChannel
    {
        private IInputChannel m_channel;

        private NetTransport transport;
        private CMQueueTransport cmTransport;
        private TibcoTransportBindingElement bindingElement;

        //private IModel m_model;

        internal TibcoChannelListener(TibcoTransportBindingElement bindingElement, BindingContext context) : base(context)
        {
            this.m_channel = null;
            this.transport = null;
            this.cmTransport = null;

            this.bindingElement = bindingElement;
        }

        private void ListenChannelClosed(object sender, EventArgs args)
        {
            base.Close();
        }

        protected override IInputChannel OnAcceptChannel(TimeSpan timeout)
        {
            if (this.m_channel != null)
            {
                return null;
            }
            this.m_channel = new TibcoInputChannel(base.Context, this.cmTransport, new EndpointAddress(this.Uri.ToString()));
            this.m_channel.Closed += new EventHandler(this.ListenChannelClosed);
            return this.m_channel;
        }

        protected override void OnClose(TimeSpan timeout)
        {
            if (this.m_channel != null)
            {
                this.m_channel.Close();
                this.m_channel = null;
            }
            if (this.cmTransport != null)
            {
                //this.m_bindingElement.Close(this.m_model, timeout);
                this.cmTransport.Destroy();
                this.cmTransport = null;
            }
        }

        protected override void OnOpen(TimeSpan timeout)
        {
            ///this.cmTransport = this.m_bindingElement.Open(timeout);
            TIBCO.Rendezvous.Environment.Open();
            this.transport = new NetTransport(bindingElement.Service, bindingElement.Network, bindingElement.Deamon);
            this.cmTransport = new CMQueueTransport(this.transport, bindingElement.DQName);
        }

        protected override bool OnWaitForChannel(TimeSpan timeout)
        {
            return false;
        }
    }
}