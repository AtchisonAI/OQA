﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading.Tasks;
using System.Xml;
using TIBCO.Rendezvous;
using Message = System.ServiceModel.Channels.Message;

namespace Tibco.ServiceModel
{
    internal sealed class TibcoInputChannel : TibcoInputChannelBase
    {
        private TibcoTransportBindingElement m_bindingElement;

        private MessageEncoder m_encoder;

        private CMQueueTransport m_model;

        private CMListener m_consumer;

        private BlockingCollection<MessageReceivedEventArgs> m_queue = new BlockingCollection<MessageReceivedEventArgs>(new ConcurrentQueue<MessageReceivedEventArgs>());

        public TibcoInputChannel(BindingContext context, CMQueueTransport model, EndpointAddress address) : base(context, address)
        {
            this.m_bindingElement = context.Binding.Elements.Find<TibcoTransportBindingElement>();
            TextMessageEncodingBindingElement maxReceivedMessageSize = context.BindingParameters.Find<TextMessageEncodingBindingElement>();
            maxReceivedMessageSize.ReaderQuotas.MaxStringContentLength = (int)this.m_bindingElement.MaxReceivedMessageSize;
            if (maxReceivedMessageSize != null)
            {
                this.m_encoder = maxReceivedMessageSize.CreateMessageEncoderFactory().Encoder;
            }
            this.m_model = model;
            this.m_consumer = null;
        }

        public override void Close(TimeSpan timeout)
        {
            if (base.State == CommunicationState.Closed || base.State == CommunicationState.Closing)
            {
                return;
            }

            base.OnClosing();

            if (this.m_consumer != null)
            {
                //this.m_model.BasicCancel(this.m_consumer.ConsumerTag);
                this.m_consumer.Destroy();
                this.m_consumer = null;
            }

            base.OnClosed();
        }

        public override void Open(TimeSpan timeout)
        {
            if (base.State != CommunicationState.Created && base.State != CommunicationState.Closed)
            {
                throw new InvalidOperationException(string.Format("Cannot open the channel from the {0} state.", base.State));
            }
            base.OnOpening();
            //string str = this.m_model.QueueDeclare();
            //this.m_model.QueueBind(str, base.Exchange, base.LocalAddress.Uri.PathAndQuery, null);
            this.m_consumer = new CMListener(Queue.Default, this.m_model, base.LocalAddress.Uri.PathAndQuery.Replace("/", "").Replace("-", ""), null);
            this.m_consumer.MessageReceived += ((object sender, MessageReceivedEventArgs args) =>
            {
                this.m_queue.Add(args);
            });

            //System.Threading.Thread.Sleep(5000);

            //this.m_model.BasicConsume(str, false, this.m_consumer);
            var t = new Task(() =>
            {
                while (true)
                {
                    if (base.State == CommunicationState.Closed || base.State == CommunicationState.Closing)
                        break;

                    Queue.Default.TimedDispatch(1);
                }
            }, TaskCreationOptions.LongRunning);
            t.Start();

            base.OnOpened();
        }

        public override Message Receive(TimeSpan timeout)
        {
            Message message;
            try
            {
                MessageReceivedEventArgs basicDeliverEventArg = this.m_queue.Take();
                var data = (string)basicDeliverEventArg.Message.GetField("DATA");
                Console.WriteLine(data);
                var bytes = System.Text.Encoding.UTF8.GetBytes(data);
                Message uri = this.m_encoder.ReadMessage(new MemoryStream(bytes), (int)this.m_bindingElement.MaxReceivedMessageSize);
                uri.Headers.To = base.LocalAddress.Uri;
                this.m_consumer.ConfirmMessage(basicDeliverEventArg.Message);
                message = uri;
            }
            catch (EndOfStreamException endOfStreamException)
            {
                if (this.m_consumer == null /*|| this.m_consumer.ShutdownReason != null && this.m_consumer.ShutdownReason.ReplyCode != 200*/)
                {
                    base.OnFaulted();
                }
                this.Close();
                message = null;
            }
            return message;
        }

        public override bool TryReceive(TimeSpan timeout, out Message message)
        {
            message = this.Receive(timeout);
            return true;
        }

        public override bool WaitForMessage(TimeSpan timeout)
        {
            throw new NotImplementedException();
        }
    }
}