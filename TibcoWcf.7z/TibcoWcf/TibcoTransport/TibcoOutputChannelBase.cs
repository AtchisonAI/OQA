﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Tibco.ServiceModel
{
    internal abstract class TibcoOutputChannelBase : TibcoChannelBase, IOutputChannel, IChannel, ICommunicationObject
    {
        private readonly EndpointAddress _address;

        private readonly Action<Message, TimeSpan> _sendMethod;

        public EndpointAddress RemoteAddress
        {
            get
            {
                return this._address;
            }
        }

        public Uri Via
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        protected TibcoOutputChannelBase(BindingContext context, EndpointAddress address) : base(context)
        {
            this._address = address;
            TibcoOutputChannelBase TibcoOutputChannelBase = this;
            this._sendMethod = new Action<Message, TimeSpan>(TibcoOutputChannelBase.Send);
        }

        public IAsyncResult BeginSend(Message message, TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this._sendMethod.BeginInvoke(message, timeout, callback, state);
        }

        public IAsyncResult BeginSend(Message message, AsyncCallback callback, object state)
        {
            return this._sendMethod.BeginInvoke(message, base.Context.Binding.SendTimeout, callback, state);
        }

        public void EndSend(IAsyncResult result)
        {
            this._sendMethod.EndInvoke(result);
        }

        public abstract void Send(Message message, TimeSpan timeout);

        public virtual void Send(Message message)
        {
            this.Send(message, base.Context.Binding.SendTimeout);
        }
    }
}