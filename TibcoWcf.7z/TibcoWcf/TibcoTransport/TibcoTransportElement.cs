﻿//----------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//----------------------------------------------------------------

using System;
using System.Configuration;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;

namespace Tibco.ServiceModel
{
    /// <summary>
    /// Configuration section for Udp. 
    /// </summary>
    public class TibcoTransportElement : BindingElementExtensionElement
    {
        public TibcoTransportElement()
        {
        }

        #region Configuration_Properties
        [ConfigurationProperty(TibcoConfigurationStrings.Service, DefaultValue = TibcoDefaults.service)]
        public string Service
        {
            get { return (string)base[TibcoConfigurationStrings.Service]; }
            set { base[TibcoConfigurationStrings.Service] = value; }
        }

        [ConfigurationProperty(TibcoConfigurationStrings.Network, DefaultValue = TibcoDefaults.network)]
        public string Network
        {
            get { return (string)base[TibcoConfigurationStrings.Network]; }
            set { base[TibcoConfigurationStrings.Network] = value; }
        }

        [ConfigurationProperty(TibcoConfigurationStrings.Deamon, DefaultValue = TibcoDefaults.deamon)]
        public string Deamon
        {
            get { return (string)base[TibcoConfigurationStrings.Deamon]; }
            set { base[TibcoConfigurationStrings.Deamon] = value; }
        }

        [ConfigurationProperty(TibcoConfigurationStrings.DQName, DefaultValue = TibcoDefaults.dqName)]
        public string DQName
        {
            get { return (string)base[TibcoConfigurationStrings.DQName]; }
            set { base[TibcoConfigurationStrings.DQName] = value; }
        }
        #endregion

        public override Type BindingElementType
        {
            get { return typeof(TibcoTransportElement); }
        }

        protected override BindingElement CreateBindingElement()
        {
            TibcoTransportBindingElement bindingElement = new TibcoTransportBindingElement();
            this.ApplyConfiguration(bindingElement);
            return bindingElement;
        }

        #region Configuration_Infrastructure_overrides
        public override void ApplyConfiguration(BindingElement bindingElement)
        {
            base.ApplyConfiguration(bindingElement);

            TibcoTransportBindingElement udpBindingElement = (TibcoTransportBindingElement)bindingElement;
            udpBindingElement.Service = this.Service;
            udpBindingElement.Network = this.Network;
            udpBindingElement.Deamon = this.Deamon;
            udpBindingElement.DQName = this.DQName;
        }

        public override void CopyFrom(ServiceModelExtensionElement from)
        {
            base.CopyFrom(from);

            var source = (TibcoTransportElement)from;
            this.Service = source.Service;
            this.Network = source.Network;
            this.Deamon = source.Deamon;
            this.DQName = source.DQName;
        }

        protected override void InitializeFrom(BindingElement bindingElement)
        {
            base.InitializeFrom(bindingElement);

            TibcoTransportBindingElement tibcoBindingElement = (TibcoTransportBindingElement)bindingElement;
            this.Service = tibcoBindingElement.Service;
            this.Network = tibcoBindingElement.Network;
            this.Deamon = tibcoBindingElement.Deamon;
            this.DQName = tibcoBindingElement.DQName;
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                ConfigurationPropertyCollection properties = base.Properties;
                properties.Add(new ConfigurationProperty(TibcoConfigurationStrings.Service,
                    typeof(string), TibcoDefaults.service, null, null, ConfigurationPropertyOptions.None));
                properties.Add(new ConfigurationProperty(TibcoConfigurationStrings.Network,
                    typeof(string), TibcoDefaults.network, null, null, ConfigurationPropertyOptions.None));
                properties.Add(new ConfigurationProperty(TibcoConfigurationStrings.Deamon,
                    typeof(string), TibcoDefaults.deamon, null, null, ConfigurationPropertyOptions.None));
                properties.Add(new ConfigurationProperty(TibcoConfigurationStrings.DQName,
                    typeof(string), TibcoDefaults.dqName, null, null, ConfigurationPropertyOptions.IsRequired));
                return properties;
            }
        }
        #endregion
    }
}
