﻿using System.ServiceModel;

namespace HiDM.CIM
{
    public class Proxy : ClientBase<IDatagramContract>
    {

        private static IDatagramContract _instance;
        public static IDatagramContract Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Proxy("DatagramService").Channel;
                }

                return _instance;
            }
        }
        protected Proxy(string endPointConfigName) : base(endPointConfigName)
        {
        }
    }
}
